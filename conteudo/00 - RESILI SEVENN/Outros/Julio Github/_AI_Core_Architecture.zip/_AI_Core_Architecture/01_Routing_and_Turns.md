# 01 — Routing and Turn Loop

## Overview

Every agent interaction is a **bounded loop**. The system must decide _which tools to activate_ (routing) and _when to stop_ (turn limits). Without both, an agent will either pick the wrong action or run indefinitely.

---

## 1. Prompt Routing

**Source:** `src/runtime.py` — `PortRuntime.route_prompt()`

### Algorithm

```
INPUT:  user prompt (string), tool/command inventory, limit (int, default 5)
OUTPUT: ranked list of RoutedMatch objects

1. Tokenize the prompt:
   - Split on whitespace, '/', and '-'
   - Lowercase all tokens
   - Store as a set (deduplicated)

2. Score each module in the inventory:
   - For each token, check if it appears in:
     a. module.name (lowercased)
     b. module.source_hint (lowercased)
     c. module.responsibility (lowercased)
   - score = count of matching tokens

3. Separate matches by kind ('command' vs 'tool')

4. Select the top match from each kind (commands first, then tools)

5. Merge remaining matches sorted by (-score, kind, name)

6. Truncate to `limit` results
```

### Key design decisions

- **Fuzzy, not exact.** The router does not require an exact command name. A prompt like "search files for TODO" will match `GrepTool` because "search" and "files" appear in its metadata.
- **Commands take priority.** The first slot is reserved for a command match, ensuring built-in operations (like `/help` or `/commit`) always surface.
- **Limit prevents overload.** The LLM only sees the top-N capabilities, not the entire inventory. This keeps the system prompt small and focused.

### How to replicate

In n8n / Make / custom middleware:

```
Webhook receives prompt
  → "Classifier" node tokenizes + scores against your tool registry
  → Returns top-N tool IDs
  → Downstream nodes only activate those tools
```

Store your tool registry as a JSON array with `name`, `description`, and `tags` fields. Score = count of prompt tokens found in those fields.

---

## 2. Turn Loop

**Source:** `src/runtime.py` — `PortRuntime.run_turn_loop()`

### Algorithm

```
INPUT:  prompt, max_turns (default 3), max_budget_tokens (default 2000)
OUTPUT: list of TurnResult objects

1. Route the prompt → get matched commands and tools

2. For turn = 0 to max_turns - 1:
   a. Build turn_prompt:
      - turn 0: original prompt
      - turn N: original prompt + " [turn N+1]"

   b. Submit to query engine (submit_message):
      - If mutable_messages.length >= config.max_turns:
          → stop_reason = "max_turns_reached", return immediately
      - Calculate projected token usage
      - If projected_usage > config.max_budget_tokens:
          → stop_reason = "max_budget_reached"
      - Otherwise:
          → stop_reason = "completed"
      - Append to transcript, compact if needed

   c. Append TurnResult to results list

   d. If stop_reason != "completed":
      → break (exit loop early)

3. Return all accumulated TurnResults
```

### Stop reasons (exhaustive)

| stop_reason | Meaning | Action |
|---|---|---|
| `completed` | Turn processed successfully | Continue to next turn |
| `max_turns_reached` | Hit the ceiling on conversation rounds | Stop loop, return results |
| `max_budget_reached` | Estimated token spend exceeds limit | Stop loop, return results |

### Critical rule: always have a ceiling

An agent without `max_turns` **will** loop forever on ambiguous prompts. An agent without `max_budget` **will** burn through API credits on complex tasks.

Recommended defaults:

| Parameter | Development | Production |
|---|---|---|
| `max_turns` | 3 | 8 |
| `max_budget_tokens` | 2,000 | 10,000–50,000 |
| `compact_after_turns` | 6 | 12 |

### Turn annotation

Note that subsequent turns append `[turn N]` to the original prompt. This serves two purposes:

1. The LLM knows it is in a multi-step interaction (prevents repetition).
2. Log analysis can distinguish first-pass from refinement turns.

---

## 3. Integration checklist

When building a new agent flow, verify:

- [ ] Every prompt goes through a routing/scoring step before tool selection
- [ ] `max_turns` is set and enforced — no unbounded loops
- [ ] `max_budget_tokens` is set — no unbounded API spend
- [ ] `stop_reason` is logged for every turn (enables debugging and analytics)
- [ ] Turn number is annotated in the prompt for multi-turn chains
- [ ] The tool registry is externalized (JSON/DB), not hardcoded in the prompt
