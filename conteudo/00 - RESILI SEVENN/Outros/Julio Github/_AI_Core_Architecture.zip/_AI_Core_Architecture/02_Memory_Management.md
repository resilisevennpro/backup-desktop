# 02 — Memory Management

## Overview

LLMs have a finite context window. If you feed every message from every turn into every subsequent request, you will hit the token limit and the agent will either crash or silently lose early context. This document describes the three-layer memory architecture used by the harness.

---

## 1. The three layers

```
┌─────────────────────────────────────────────┐
│  Layer 1: Mutable Messages (hot)            │
│  In-memory list, actively sent to the LLM   │
│  Compacted via sliding window               │
├─────────────────────────────────────────────┤
│  Layer 2: Transcript Store (warm)           │
│  In-memory buffer of all entries            │
│  Compacted in parallel with Layer 1         │
│  Can be replayed or flushed                 │
├─────────────────────────────────────────────┤
│  Layer 3: Persisted Session (cold)          │
│  JSON on disk: {session_id, messages,       │
│  input_tokens, output_tokens}               │
│  Stateless, restorable by ID               │
└─────────────────────────────────────────────┘
```

---

## 2. Sliding window compaction

**Source:** `src/query_engine.py` — `compact_messages_if_needed()` and `src/transcript.py`

### Algorithm

```
TRIGGER: called after every submit_message()

IF len(mutable_messages) > compact_after_turns:
    mutable_messages = mutable_messages[-compact_after_turns:]

IF len(transcript_store.entries) > compact_after_turns:
    transcript_store.entries = transcript_store.entries[-compact_after_turns:]
```

### Parameters

| Parameter | Default | Purpose |
|---|---|---|
| `compact_after_turns` | 12 | Number of recent messages to retain |

### What this means in practice

- Messages 1 through (N - 12) are **dropped from active memory**.
- They are NOT deleted from the persisted session — only from the hot buffer.
- The LLM always sees the most recent 12 messages, which is typically enough to maintain conversational coherence.

### Why a sliding window and not summarization?

Summarization requires an extra LLM call (cost + latency) and introduces information loss that is hard to control. A sliding window is:

- **Deterministic** — you know exactly what the LLM sees.
- **Zero-cost** — no extra API calls.
- **Predictable** — the context budget is always `compact_after_turns * avg_message_tokens`.

For production systems with very long sessions (50+ turns), consider a hybrid: sliding window for hot context + a one-time summary of compacted messages injected as a system-level "session recap".

---

## 3. Session persistence (stateless JSON)

**Source:** `src/session_store.py`

### Schema

```json
{
  "session_id": "a1b2c3d4...",
  "messages": ["user prompt 1", "user prompt 2", "..."],
  "input_tokens": 347,
  "output_tokens": 512
}
```

### Operations

| Operation | Function | Behavior |
|---|---|---|
| **Save** | `save_session(session)` | Serializes to `.port_sessions/{session_id}.json` |
| **Load** | `load_session(session_id)` | Reads JSON, returns `StoredSession` dataclass |
| **Restore** | `QueryEnginePort.from_saved_session(id)` | Rebuilds engine with messages + usage from disk |

### Key properties

1. **Stateless.** The session file contains everything needed to restore the engine. No external database, no server state.
2. **Portable.** JSON files can be moved between environments (local, CI, cloud).
3. **Resumable.** Call `from_saved_session(id)` to pick up exactly where the previous run left off.

---

## 4. Transcript Store details

**Source:** `src/transcript.py`

```python
class TranscriptStore:
    entries: list[str]     # all messages in order
    flushed: bool          # whether flush() has been called

    append(entry)          # add a message, set flushed = False
    compact(keep_last)     # sliding window trim
    replay()               # return all entries as tuple
    flush()                # mark as flushed (ready to persist)
```

The `flushed` flag is a simple state gate: `persist_session()` calls `flush()` first, then serializes. This prevents double-writes and signals to callers that the transcript is safe to read.

---

## 5. Integration recipe

### For n8n / Make

```
[Start] → LLM Node → [Store response in array variable]
                            │
                            ▼
                    Array length > 12?
                     ├── YES → Slice to last 12 → Feed to next LLM call
                     └── NO  → Feed full array to next LLM call
                            │
                            ▼
                    [At end of flow] → HTTP Request: POST session JSON
                                       to your storage (Supabase, S3, Redis)
```

### For custom Python middleware

```python
class SessionManager:
    def __init__(self, compact_after: int = 12):
        self.messages: list[dict] = []
        self.compact_after = compact_after

    def add(self, role: str, content: str):
        self.messages.append({"role": role, "content": content})
        if len(self.messages) > self.compact_after:
            self.messages = self.messages[-self.compact_after:]

    def save(self, path: str):
        Path(path).write_text(json.dumps(self.messages, indent=2))

    @classmethod
    def load(cls, path: str) -> "SessionManager":
        mgr = cls()
        mgr.messages = json.loads(Path(path).read_text())
        return mgr
```

---

## 6. Checklist

- [ ] Every agent flow has a `compact_after_turns` parameter (never unbounded message lists)
- [ ] Sessions are serialized as self-contained JSON (no implicit server state)
- [ ] Session restore rebuilds the full engine state from the JSON alone
- [ ] The `flushed` flag (or equivalent) prevents concurrent writes
- [ ] Token usage is tracked per-session for cost monitoring
