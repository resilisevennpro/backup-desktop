# 04 — Implementation Guidelines

## Overview

This document translates the three core patterns (Routing, Memory, Security) into actionable middleware recipes. Each section shows the pattern, the decision points, and a concrete integration sketch for real-world projects like Nexus AI, clinic dashboards, or n8n/Make automation flows.

---

## 1. Architecture at a glance

```
User / External Trigger
        │
        ▼
┌──────────────────┐
│  ROUTING LAYER   │  Tokenize prompt → score against tool registry → top-N
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  PERMISSION GATE │  Load 03_Security_and_AutoMode.json → classify risk
│                  │  → auto-approve or request human confirmation
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  TURN LOOP       │  For each turn (up to max_turns):
│                  │    → call LLM with prompt + matched tools
│                  │    → check stop_reason (completed / budget / turns)
│                  │    → compact context if needed
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  PERSISTENCE     │  Serialize session → store as JSON
│                  │  (Supabase, Redis, S3, local file)
└──────────────────┘
```

---

## 2. Routing layer — how to build it

### The tool registry

Create a single source of truth for all tools your agent can use. This replaces hardcoded if/else chains.

```json
[
  {
    "id": "search_patient",
    "name": "Search Patient Records",
    "tags": ["patient", "search", "clinic", "records", "lookup"],
    "description": "Search the clinic database for patient records by name, ID, or date.",
    "risk_level": "read_only",
    "endpoint": "/api/patients/search"
  },
  {
    "id": "update_appointment",
    "name": "Update Appointment",
    "tags": ["appointment", "schedule", "update", "modify", "calendar"],
    "description": "Modify an existing appointment's date, time, or provider.",
    "risk_level": "low_risk",
    "endpoint": "/api/appointments/{id}"
  },
  {
    "id": "send_sms_reminder",
    "name": "Send SMS Reminder",
    "tags": ["sms", "notification", "reminder", "patient", "message"],
    "description": "Send an SMS reminder to a patient about an upcoming appointment.",
    "risk_level": "high_risk",
    "endpoint": "/api/notifications/sms"
  }
]
```

### Scoring function

```python
def score_tools(prompt: str, registry: list[dict], limit: int = 5) -> list[dict]:
    tokens = set(prompt.lower().split())
    scored = []
    for tool in registry:
        haystacks = [
            tool["name"].lower(),
            tool["description"].lower(),
            " ".join(tool["tags"]),
        ]
        score = sum(
            1 for token in tokens
            if any(token in h for h in haystacks)
        )
        if score > 0:
            scored.append({**tool, "_score": score})
    scored.sort(key=lambda t: -t["_score"])
    return scored[:limit]
```

### In n8n

1. **Webhook** node receives the user prompt.
2. **Code** node runs the scoring function against your tool registry (stored as a static JSON or fetched from Supabase).
3. **Switch** node branches based on the top match's `id`.
4. Each branch executes the corresponding API call or LLM tool.

---

## 3. Permission gate — how to enforce it

### Load the risk matrix

```python
import json

with open("03_Security_and_AutoMode.json") as f:
    RISK_MATRIX = json.load(f)

# Build a lookup: tool_name → risk_level
TOOL_RISK = {}
for level in ["read_only", "low_risk", "medium_risk", "high_risk"]:
    for tool in RISK_MATRIX[level]["tools"]:
        TOOL_RISK[tool["name"]] = level
```

### Decision function

```python
def should_auto_approve(tool_name: str, mode: str, command: str = "") -> bool:
    risk = TOOL_RISK.get(tool_name, "high_risk")  # unknown = high_risk

    if risk == "read_only":
        return True

    if mode == "interactive":
        return False  # everything except read_only needs approval

    if mode == "auto":
        if risk == "low_risk":
            return True
        if risk == "medium_risk":
            return classify_command(command) != "destructive"
        return False  # high_risk always needs approval

    if mode == "swarm_worker":
        return risk in ("read_only",)  # workers are heavily restricted

    return False


def classify_command(command: str) -> str:
    """Simplified command semantics classifier."""
    destructive_patterns = [
        "rm -rf", "rm -r", "drop table", "delete from",
        "git push --force", "git reset --hard",
        "truncate", "format", "fdisk",
    ]
    read_patterns = [
        "ls", "cat", "head", "tail", "grep", "find",
        "git status", "git log", "git diff", "echo", "pwd",
    ]
    cmd_lower = command.lower().strip()
    for pattern in destructive_patterns:
        if pattern in cmd_lower:
            return "destructive"
    for pattern in read_patterns:
        if cmd_lower.startswith(pattern):
            return "read_only"
    return "non_destructive_write"
```

### In n8n / Make

1. After the routing node selects a tool, pass the tool name to a **Code** node.
2. The Code node loads the risk matrix and calls `should_auto_approve()`.
3. If `True` → proceed to execution.
4. If `False` → route to a **Wait for Approval** node (Slack message, email, webhook callback).

---

## 4. Turn loop — how to implement it

### Python middleware

```python
class TurnLoop:
    def __init__(self, llm_client, max_turns=8, max_budget=10000):
        self.llm = llm_client
        self.max_turns = max_turns
        self.max_budget = max_budget
        self.messages = []
        self.total_tokens = 0

    def run(self, prompt: str, tools: list[dict]) -> list[dict]:
        results = []
        for turn in range(self.max_turns):
            turn_prompt = prompt if turn == 0 else f"{prompt} [turn {turn + 1}]"
            self.messages.append({"role": "user", "content": turn_prompt})

            response = self.llm.chat(
                messages=self.messages,
                tools=tools,
            )

            self.total_tokens += response.usage.total_tokens
            self.messages.append({"role": "assistant", "content": response.content})

            # Compact if needed
            if len(self.messages) > 24:  # compact_after_turns * 2 (user+assistant)
                self.messages = self.messages[-24:]

            # Check stop conditions
            if self.total_tokens > self.max_budget:
                results.append({"turn": turn, "stop_reason": "max_budget_reached"})
                break

            if response.stop_reason == "end_turn":
                results.append({"turn": turn, "stop_reason": "completed"})
                break

            results.append({"turn": turn, "stop_reason": "continue"})

        return results
```

### In n8n

Use a **Loop** node with:
- **Max iterations** = `max_turns`
- Inside the loop: LLM node → Code node (check token count, check stop_reason)
- **Break condition**: `stop_reason != "continue"` OR `total_tokens > max_budget`
- After loop: **HTTP Request** to persist the session JSON.

---

## 5. Applying to specific projects

### Nexus AI (multi-tenant AI platform)

| Layer | Implementation |
|---|---|
| Tool registry | Supabase table `ai_tools` with columns: `id`, `name`, `tags[]`, `risk_level`, `endpoint`, `tenant_id` |
| Permission gate | Edge Function that loads risk matrix + tenant's permission mode from `ai_settings` |
| Turn loop | Server-side Python service with per-tenant `max_turns` and `max_budget` from config |
| Session persistence | Supabase table `ai_sessions` — one row per session, `messages` as JSONB |
| Approval flow | Slack webhook for `high_risk` actions → user clicks Approve/Deny → callback updates session |

### Clinic dashboard (appointment management)

| Layer | Implementation |
|---|---|
| Tool registry | Static JSON shipped with the app (tools don't change often) |
| Permission gate | All patient-data-modifying tools are `low_risk` (auto in auto-mode). SMS/email sends are `high_risk` (always confirm). |
| Turn loop | Frontend: max 3 turns (quick interactions). Backend batch jobs: max 8 turns. |
| Session persistence | Redis with TTL = 24h (sessions don't need to live forever) |
| Approval flow | In-app modal for `high_risk` actions (e.g., "Send SMS to 47 patients? [Confirm / Cancel]") |

### n8n / Make generic template

```
[Webhook: receive prompt]
    → [Code: score tools from registry]
    → [Code: check permission gate]
    → [IF: approved?]
        ├── YES → [Loop: turn loop with LLM]
        │            → [Code: compact messages]
        │            → [Code: check stop conditions]
        │            → [HTTP: persist session to Supabase]
        └── NO  → [Slack: request approval]
                    → [Wait for webhook callback]
                    → [Loop: continue as above]
```

---

## 6. Summary checklist

- [ ] Tool registry is externalized (JSON, DB) — never hardcoded in prompts
- [ ] Every tool has an explicit `risk_level` classification
- [ ] `should_auto_approve()` is called before every tool execution
- [ ] Unknown tools default to `high_risk`
- [ ] Turn loop has both `max_turns` and `max_budget` enforced
- [ ] Context compaction is applied after every turn (sliding window)
- [ ] Sessions are persisted as self-contained JSON with `session_id`
- [ ] Destructive commands are pattern-matched and blocked even in Auto Mode
- [ ] High-risk actions route through a human approval channel
- [ ] All stop_reasons are logged for debugging and analytics
