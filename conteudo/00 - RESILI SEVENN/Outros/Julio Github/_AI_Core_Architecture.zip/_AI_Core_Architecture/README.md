# AI Core Architecture — Padroes de Referencia

Esta pasta contém os **padrões ouro de engenharia de agentes autônomos** destilados da arquitetura do Claude Code. Cada documento aqui foi escrito para que um desenvolvedor humano _ou_ um assistente de IA possa ler e aplicar imediatamente os padrões em novos sistemas.

## Por que isso existe

Durante nossa análise do runtime do Claude Code (o rewrite em Python no `src/`), identificamos três decisões de design estruturais que mantêm o agente seguro, eficiente e previsível. Esses padrões **não são específicos de framework** — funcionam em qualquer stack (Python, Node, n8n, Make, middleware customizado).

## Os três padrões centrais

### 1. Turn Loop com Roteamento (`01_Routing_and_Turns.md`)

O agente não roda para sempre. Cada interação é limitada por:

- **max_turns** — teto rígido de rodadas de conversa (padrão: 8).
- **max_budget_tokens** — limite estimado de gasto de tokens (padrão: 2000).
- **Roteamento fuzzy** — o prompt é tokenizado e pontuado contra um inventário de tools/comandos para que o sistema escolha as capacidades certas _antes_ da LLM ver a requisição.

Se qualquer limite for atingido, o agente para de forma limpa com um `stop_reason` tipado, em vez de entrar em loop ou alucinar.

### 2. Compactação de Janela de Contexto (`02_Memory_Management.md`)

O contexto de uma LLM é finito. O sistema usa uma **sliding window** (`compact_after_turns`) para manter apenas as N mensagens mais recentes em memória ativa, enquanto o transcript completo é serializado em disco como JSON stateless. Sessões podem ser restauradas a partir de qualquer ponto pelo ID.

### 3. Matriz de Risco / Auto Mode (`03_Security_and_AutoMode.json`)

As ferramentas são classificadas por nível de risco:

| Nível | Exemplo | Auto-aprovação? |
|---|---|---|
| **read-only** | FileRead, Glob, Grep | Sempre |
| **low_risk** | FileEdit, FileWrite | Sim, no Auto Mode |
| **medium_risk** | Bash, PowerShell | Somente se a semântica do comando indicar "leitura" ou "escrita não-destrutiva" |
| **high_risk** | RemoteTrigger, TeamDelete, MCP auth | Nunca — exige aprovação humana |

O arquivo JSON é legível por máquina e pode ser carregado diretamente nas verificações de permissão do middleware.

## Como usar estes documentos

- **Construindo um novo middleware de agente?** Comece pelo `04_Implementation_Guidelines.md` para a receita de integração.
- **Configurando limites de turnos?** Veja `01_Routing_and_Turns.md` para a árvore de decisão exata.
- **Debugando contexto descontrolado?** Veja `02_Memory_Management.md` para o algoritmo de compactação.
- **Montando gates de permissão?** Carregue `03_Security_and_AutoMode.json` como sua matriz de risco padrão e sobrescreva por projeto.

## Público-alvo

- Desenvolvedores humanos integrando agentes de IA em produtos (Nexus AI, painéis de clínicas, fluxos de automação).
- Assistentes de IA (como o Claude) que precisam se auto-configurar quando inseridos em um novo projeto — leiam estes arquivos e apliquem os padrões.

---

> Estes padrões foram extraídos dos arquivos `src/runtime.py`, `src/query_engine.py`, `src/permissions.py` e `src/reference_data/` deste repositório. O código-fonte original em TypeScript que eles espelham é proprietário; o que você vê aqui é a _lógica arquitetural_, não código copiado.
