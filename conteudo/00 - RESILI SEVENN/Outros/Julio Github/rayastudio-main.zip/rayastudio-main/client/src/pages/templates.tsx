import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus, FileText, Trash2, Edit, Globe, Upload, Loader2, Image, Sparkles, ImageIcon, Layers } from "lucide-react";
import { useForm, Controller } from "react-hook-form";
import type { Template, Project } from "@shared/schema";

type FormValues = {
  name: string;
  description: string;
  platform: string;
  format: string;
  captionTemplate: string;
  promptTemplate: string;
  referenceImageUrl: string;
  slideCount: number | null;
  category: string;
  isGlobal: boolean;
  projectId: number | null;
};

export default function Templates() {
  const [open, setOpen] = useState(false);
  const [editItem, setEditItem] = useState<Template | null>(null);
  const [extractOpen, setExtractOpen] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [extractResult, setExtractResult] = useState<any>(null);
  const [extractPreview, setExtractPreview] = useState<string | null>(null);
  const extractFileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const { data: templates = [], isLoading } = useQuery<Template[]>({ queryKey: ["/api/templates"] });
  const { data: projects = [] } = useQuery<Project[]>({ queryKey: ["/api/projects"] });

  const defaultValues: FormValues = {
    name: "", description: "", platform: "any", format: "any",
    captionTemplate: "", promptTemplate: "", referenceImageUrl: "",
    slideCount: null, category: "", isGlobal: true, projectId: null,
  };

  const form = useForm<FormValues>({ defaultValues });
  const watchedFormat = form.watch("format");

  const openCreate = () => {
    setEditItem(null);
    form.reset(defaultValues);
    setOpen(true);
  };

  const openEdit = (t: Template) => {
    setEditItem(t);
    form.reset({
      name: t.name,
      description: t.description || "",
      platform: t.platform || "any",
      format: t.format || "any",
      captionTemplate: t.captionTemplate || "",
      promptTemplate: t.promptTemplate || "",
      referenceImageUrl: t.referenceImageUrl || "",
      slideCount: (t as any).slideCount ?? null,
      category: t.category || "",
      isGlobal: t.isGlobal ?? true,
      projectId: t.projectId || null,
    });
    setOpen(true);
  };

  const saveMutation = useMutation({
    mutationFn: (data: FormValues) => {
      const cleaned = {
        ...data,
        platform: data.platform === "any" ? null : data.platform,
        format: data.format === "any" ? null : data.format,
        referenceImageUrl: data.referenceImageUrl || null,
        slideCount: data.format === "carrossel" && data.slideCount ? Number(data.slideCount) : null,
      };
      return editItem ? apiRequest("PATCH", `/api/templates/${editItem.id}`, cleaned) : apiRequest("POST", "/api/templates", cleaned);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
      setOpen(false);
      toast({ title: editItem ? "Template atualizado!" : "Template criado!" });
    },
    onError: () => toast({ title: "Erro ao salvar template", variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/templates/${id}`),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/templates"] }); toast({ title: "Template removido" }); },
  });

  const handleExtractImage = async (file: File) => {
    setExtracting(true);
    setExtractResult(null);
    const reader = new FileReader();
    reader.onload = (e) => setExtractPreview(e.target?.result as string);
    reader.readAsDataURL(file);
    try {
      const formData = new FormData();
      formData.append("image", file);
      const res = await fetch("/api/ai/analyze-image", { method: "POST", body: formData });
      const data = await res.json();
      setExtractResult(data);
      toast({ title: "Imagem analisada! Revise e salve como template." });
    } catch {
      toast({ title: "Erro ao analisar imagem", variant: "destructive" });
    } finally {
      setExtracting(false);
    }
  };

  const saveExtractedAsTemplate = () => {
    if (!extractResult) return;

    const isCarousel = extractResult.isCarousel || extractResult.contentStructure === "carousel";
    const slideCount = isCarousel ? (extractResult.slideCount || null) : null;
    const detectedFormat = isCarousel ? "carrossel" : "post";

    const captionStructure = isCarousel && slideCount
      ? buildCarouselCaptionTemplate(slideCount, extractResult.suggestedCaption)
      : extractResult.suggestedCaption
        ? `[HOOK/TÍTULO]\n\n${extractResult.suggestedCaption}\n\n[HASHTAGS]`
        : "[HOOK/TÍTULO]\n\n[CORPO DO CONTEÚDO]\n\n[CHAMADA PARA AÇÃO]\n\n[HASHTAGS]";

    form.reset({
      name: isCarousel
        ? `Carrossel: ${extractResult.contentType || "Referência"}`
        : `Post: ${extractResult.contentType || "Referência"}`,
      description: extractResult.description
        ? extractResult.description.slice(0, 120) + (extractResult.description.length > 120 ? "..." : "")
        : "Template extraído a partir de imagem de referência.",
      platform: "any",
      format: detectedFormat,
      captionTemplate: captionStructure,
      promptTemplate: extractResult.imagePromptToReplicate || "",
      referenceImageUrl: extractPreview || "",
      slideCount: slideCount,
      category: extractResult.contentType || (isCarousel ? "Carrossel" : "Estático"),
      isGlobal: true,
      projectId: null,
    });
    setEditItem(null);
    setExtractOpen(false);
    setOpen(true);
  };

  const buildCarouselCaptionTemplate = (slides: number, suggestedCaption?: string): string => {
    const hook = suggestedCaption?.split("\n")[0] || "[HOOK CHAMATIVO — primeira frase que para o scroll]";
    let template = `${hook}\n\nDeslize para ver →\n\n`;
    for (let i = 1; i <= slides; i++) {
      if (i === 1) template += `📌 Slide 1: [PROBLEMA ou CONTEXTO]\n`;
      else if (i === slides) template += `📌 Slide ${i}: [CTA — o que o seguidor deve fazer agora]\n`;
      else template += `📌 Slide ${i}: [PONTO ${i} — dica, dado ou argumento]\n`;
    }
    template += `\n[HASHTAGS]`;
    return template;
  };

  const platformLabels: Record<string, string> = { instagram: "Instagram", linkedin: "LinkedIn", tiktok: "TikTok" };
  const formatLabels: Record<string, string> = { post: "Estático", story: "Story", carrossel: "Carrossel", reels: "Reels" };

  const hasVisualRef = (t: Template) => !!(t.referenceImageUrl || t.promptTemplate);
  const getSlideCount = (t: Template) => (t as any).slideCount as number | null | undefined;

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground">Templates</h1>
          <p className="text-sm text-muted-foreground">Modelos de conteúdo com referências visuais para a IA</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => { setExtractResult(null); setExtractPreview(null); setExtractOpen(true); }} data-testid="button-extract-from-image">
            <Image className="w-4 h-4 mr-1" /> Extrair de Imagem
          </Button>
          <Button size="sm" onClick={openCreate} data-testid="button-create-template">
            <Plus className="w-4 h-4 mr-1" /> Novo Template
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid md:grid-cols-2 gap-3">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 rounded-md" />)}
        </div>
      ) : templates.length === 0 ? (
        <Card>
          <CardContent className="p-12 flex flex-col items-center gap-3">
            <FileText className="w-12 h-12 text-muted-foreground" />
            <p className="text-sm text-muted-foreground text-center">Nenhum template ainda.<br />Crie templates ou extraia de uma imagem de referência.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {templates.map((t) => {
            const slides = getSlideCount(t);
            return (
              <Card key={t.id} className="group overflow-hidden" data-testid={`template-${t.id}`}>
                <div className="flex">
                  {t.referenceImageUrl && (
                    <div className="w-24 shrink-0 bg-muted overflow-hidden relative">
                      <img src={t.referenceImageUrl} alt="Referência visual" className="w-full h-full object-cover" style={{ minHeight: "90px" }} />
                      {slides && (
                        <div className="absolute bottom-1 left-0 right-0 flex justify-center">
                          <span className="text-[10px] font-semibold bg-black/70 text-white px-1.5 py-0.5 rounded-full">
                            {slides} slides
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                  <CardContent className="p-4 space-y-2 flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{t.name}</p>
                        {t.isGlobal && <Badge variant="secondary" className="text-xs shrink-0"><Globe className="w-3 h-3 mr-1" />Global</Badge>}
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                        <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => openEdit(t)}>
                          <Edit className="w-3.5 h-3.5 text-muted-foreground" />
                        </Button>
                        <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => deleteMutation.mutate(t.id)}>
                          <Trash2 className="w-3.5 h-3.5 text-muted-foreground" />
                        </Button>
                      </div>
                    </div>
                    {t.description && <p className="text-xs text-muted-foreground line-clamp-2">{t.description}</p>}
                    <div className="flex flex-wrap gap-1">
                      {t.platform && <Badge variant="outline" className="text-xs">{platformLabels[t.platform] || t.platform}</Badge>}
                      {t.format && (
                        <Badge variant="outline" className="text-xs">
                          {t.format === "carrossel" && <Layers className="w-3 h-3 mr-1" />}
                          {formatLabels[t.format] || t.format}
                          {slides ? ` · ${slides} slides` : ""}
                        </Badge>
                      )}
                      {t.category && <Badge variant="outline" className="text-xs">{t.category}</Badge>}
                      {hasVisualRef(t) && (
                        <Badge variant="outline" className="text-xs text-primary border-primary/30 bg-primary/5">
                          <ImageIcon className="w-3 h-3 mr-1" />Ref. visual
                        </Badge>
                      )}
                    </div>
                    {t.captionTemplate && (
                      <p className="text-xs text-muted-foreground bg-muted rounded-sm p-2 line-clamp-2">{t.captionTemplate}</p>
                    )}
                  </CardContent>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Template create/edit dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editItem ? "Editar Template" : "Criar Template"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit((d) => saveMutation.mutate(d))} className="space-y-3">
            <div className="space-y-1">
              <Label>Nome *</Label>
              <Input placeholder="Ex: Post de Lançamento" data-testid="input-template-name" {...form.register("name", { required: true })} />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label>Plataforma</Label>
                <Controller name="platform" control={form.control} render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className="h-8"><SelectValue placeholder="Qualquer" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Qualquer</SelectItem>
                      <SelectItem value="instagram">Instagram</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="tiktok">TikTok</SelectItem>
                    </SelectContent>
                  </Select>
                )} />
              </div>
              <div className="space-y-1">
                <Label>Tipo de Conteúdo</Label>
                <Controller name="format" control={form.control} render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className="h-8"><SelectValue placeholder="Qualquer" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Qualquer</SelectItem>
                      <SelectItem value="post">Estático</SelectItem>
                      <SelectItem value="carrossel">Carrossel</SelectItem>
                      <SelectItem value="story">Story</SelectItem>
                      <SelectItem value="reels">Reels</SelectItem>
                    </SelectContent>
                  </Select>
                )} />
              </div>
            </div>

            {watchedFormat === "carrossel" && (
              <div className="space-y-1 p-3 rounded-md border border-primary/20 bg-primary/5">
                <Label className="flex items-center gap-1.5 text-primary">
                  <Layers className="w-3.5 h-3.5" /> Número de Slides
                </Label>
                <div className="flex items-center gap-3">
                  <Input
                    type="number"
                    min={2}
                    max={20}
                    placeholder="Ex: 5"
                    className="h-8 w-24"
                    data-testid="input-slide-count"
                    {...form.register("slideCount", { valueAsNumber: true, min: 2, max: 20 })}
                  />
                  <p className="text-xs text-muted-foreground">slides (mín. 2, máx. 20)</p>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Isso define a estrutura da legenda e a lógica de criação das imagens do carrossel.
                </p>
              </div>
            )}

            <div className="space-y-1">
              <Label>Categoria</Label>
              <Input placeholder="Ex: Lançamento, Engajamento, Educativo..." {...form.register("category")} />
            </div>
            <div className="space-y-1">
              <Label>Descrição</Label>
              <Input placeholder="Para que serve este template?" {...form.register("description")} />
            </div>
            <div className="space-y-1">
              <Label>Template de Legenda</Label>
              <Textarea
                placeholder={watchedFormat === "carrossel"
                  ? "Ex: [HOOK]\n\nDeslize para ver →\n\n📌 Slide 1: [CONTEXTO]\n📌 Slide 2: [DICA]\n...\n📌 Slide N: [CTA]\n\n[HASHTAGS]"
                  : "Ex: [HEADLINE]\n\n[CORPO DO POST]\n\nO que você achou? Conta nos comentários!"}
                rows={6}
                className="resize-none"
                {...form.register("captionTemplate")}
              />
            </div>
            <div className="space-y-1">
              <Label>Prompt Visual <span className="text-muted-foreground text-xs font-normal">(descreve o estilo visual para gerar imagens)</span></Label>
              <Textarea
                placeholder={watchedFormat === "carrossel"
                  ? "Ex: Vertical carousel slide, dark background, slide number indicator at bottom, bold white headline at top, orange accent color, clean sans-serif typography..."
                  : "Ex: Dark background with orange accents, 3D graphic element, bold white sans-serif typography..."}
                rows={4}
                className="resize-none"
                {...form.register("promptTemplate")}
              />
            </div>

            {form.watch("referenceImageUrl") && (
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Imagem de referência salva</Label>
                <div className="relative w-full rounded-md overflow-hidden border border-border">
                  <img src={form.watch("referenceImageUrl")} alt="Referência" className="w-full object-contain max-h-32" />
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="absolute top-2 right-2 h-6 text-xs bg-background/80"
                    onClick={() => form.setValue("referenceImageUrl", "")}
                  >
                    Remover
                  </Button>
                </div>
              </div>
            )}

            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" size="sm" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button type="submit" size="sm" disabled={saveMutation.isPending} data-testid="button-submit-template">
                {saveMutation.isPending ? "Salvando..." : "Salvar Template"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Extract from image dialog */}
      <Dialog open={extractOpen} onOpenChange={setExtractOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              Extrair Template de Imagem
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Envie um post estático ou slide de carrossel de referência. A IA vai detectar o tipo de conteúdo, quantos slides tem e extrair o estilo visual completo.
            </p>

            <div
              className="border-2 border-dashed border-border rounded-md p-6 text-center cursor-pointer hover-elevate"
              onClick={() => extractFileRef.current?.click()}
              data-testid="extract-upload-zone"
            >
              <input
                ref={extractFileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => { if (e.target.files?.[0]) handleExtractImage(e.target.files[0]); }}
              />
              {extracting ? (
                <div className="flex flex-col items-center gap-2">
                  <Loader2 className="w-8 h-8 text-primary animate-spin" />
                  <p className="text-sm text-muted-foreground">Detectando tipo, slides e estilo visual...</p>
                </div>
              ) : extractPreview ? (
                <div className="space-y-2">
                  <img src={extractPreview} alt="Preview" className="max-h-48 mx-auto rounded-md object-contain" />
                  <p className="text-xs text-muted-foreground">Clique para trocar a imagem</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2">
                  <Upload className="w-8 h-8 text-muted-foreground" />
                  <p className="text-sm font-medium text-foreground">Clique para enviar uma imagem</p>
                  <p className="text-xs text-muted-foreground">Post estático ou slide de carrossel · PNG, JPG, WEBP</p>
                </div>
              )}
            </div>

            {extractResult && (
              <div className="space-y-3 p-3 rounded-md border border-border bg-muted/30">
                <p className="text-xs font-semibold text-foreground">Análise da IA</p>

                {/* Content type detection banner */}
                <div className={`flex items-center gap-2 p-2 rounded-md text-xs font-medium ${
                  (extractResult.isCarousel || extractResult.contentStructure === "carousel")
                    ? "bg-primary/10 text-primary border border-primary/20"
                    : "bg-muted text-muted-foreground border border-border"
                }`}>
                  {(extractResult.isCarousel || extractResult.contentStructure === "carousel") ? (
                    <>
                      <Layers className="w-4 h-4 shrink-0" />
                      <span>
                        Carrossel detectado
                        {extractResult.slideCount ? ` · ${extractResult.slideCount} slides` : ""}
                      </span>
                    </>
                  ) : (
                    <>
                      <ImageIcon className="w-4 h-4 shrink-0" />
                      <span>Post estático detectado</span>
                    </>
                  )}
                </div>

                {extractResult.description && (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-0.5">Descrição</p>
                    <p className="text-xs text-foreground">{extractResult.description}</p>
                  </div>
                )}
                {extractResult.style?.mood && (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-0.5">Tom Visual</p>
                    <p className="text-xs text-foreground">{extractResult.style.mood}</p>
                  </div>
                )}
                {extractResult.style?.composition && (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-0.5">Composição</p>
                    <p className="text-xs text-foreground">{extractResult.style.composition}</p>
                  </div>
                )}
                {extractResult.contentType && (
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-medium text-muted-foreground">Categoria:</p>
                    <Badge variant="outline" className="text-xs">{extractResult.contentType}</Badge>
                  </div>
                )}
                {extractResult.imagePromptToReplicate && (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-0.5">Prompt visual (para replicar)</p>
                    <p className="text-xs text-foreground bg-muted p-2 rounded-sm line-clamp-4">{extractResult.imagePromptToReplicate}</p>
                  </div>
                )}
                {extractResult.suggestedCaption && (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-0.5">Legenda sugerida</p>
                    <p className="text-xs text-foreground bg-muted p-2 rounded-sm line-clamp-3">{extractResult.suggestedCaption}</p>
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-2 justify-end">
              <Button type="button" variant="outline" size="sm" onClick={() => setExtractOpen(false)}>Cancelar</Button>
              {extractResult && (
                <Button size="sm" onClick={saveExtractedAsTemplate} data-testid="button-save-extracted-template">
                  <Plus className="w-4 h-4 mr-1" /> Salvar como Template
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
