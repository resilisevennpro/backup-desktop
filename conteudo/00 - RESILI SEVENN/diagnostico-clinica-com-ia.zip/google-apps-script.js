// google-apps-script.js
// Siga as instruções abaixo para configurar o recebimento de dados no Google Sheets

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var data = JSON.parse(e.postData.contents);
    
    // Verifica se é a primeira vez para criar os cabeçalhos
    if (sheet.getLastRow() === 0) {
      var headers = [
        "Data/Hora", "Nome", "WhatsApp", "Instagram", 
        "Score", "Perfil", 
        "Q1 Origem Pacientes", "Q2 Situação Agenda", "Q3 Investe Anúncios",
        "Q4 Tempo Resposta", "Q5 Follow-up", "Q6 Quem Responde",
        "Q7 Conversão Contatos", "Q8 Procedimento Top",
        "Q9 Retenção", "Q10 Controle Pacientes",
        "Q11 Faturamento", "Q12 Maior Dor",
        "Valor Perdido Mês", 
        "Gargalo 1 Título", "Gargalo 1 Descrição",
        "Gargalo 2 Título", "Gargalo 2 Descrição",
        "Gargalo 3 Título", "Gargalo 3 Descrição"
      ];
      sheet.appendRow(headers);
      sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold");
    }
    
    var rowData = [
      data.data_hora || new Date().toISOString(),
      data.nome || "",
      data.whatsapp || "",
      data.instagram || "",
      data.score || 0,
      data.perfil || "",
      data.q1_origem_pacientes || "",
      data.q2_situacao_agenda || "",
      data.q3_investe_anuncios || "",
      data.q4_tempo_resposta || "",
      data.q5_followup || "",
      data.q6_quem_responde || "",
      data.q7_conversao_contatos || "",
      data.q8_procedimento_top || "",
      data.q9_retencao || "",
      data.q10_controle_pacientes || "",
      data.q11_faturamento || "",
      data.q12_maior_dor || "",
      data.valor_perdido_mes || 0,
      data.gargalo_1_titulo || "",
      data.gargalo_1_descricao || "",
      data.gargalo_2_titulo || "",
      data.gargalo_2_descricao || "",
      data.gargalo_3_titulo || "",
      data.gargalo_3_descricao || ""
    ];
    
    sheet.appendRow(rowData);
    
    return ContentService.createTextOutput(JSON.stringify({"status": "success"}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({"status": "error", "message": error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/*
INSTRUÇÕES DE USO:
1. Crie uma nova planilha no Google Sheets.
2. No menu superior, clique em "Extensões" > "Apps Script".
3. Apague o código padrão e cole todo este código lá.
4. Salve o projeto (ícone de disquete).
5. Clique no botão azul "Implantar" (Deploy) no canto superior direito > "Nova implantação".
6. Clique no ícone de engrenagem ao lado de "Selecione o tipo" e escolha "App da Web" (Web app).
7. Em "Executar como", deixe "Eu".
8. Em "Quem tem acesso", mude para "Qualquer pessoa" (Anyone).
9. Clique em "Implantar". Autorize os acessos se o Google pedir.
10. Copie a "URL do app da Web" gerada.
11. Cole essa URL no arquivo .env do seu projeto na variável VITE_SHEETS_WEBHOOK_URL.
*/
