/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DiagnosticoProvider, useDiagnostico } from './context/DiagnosticoContext';
import Landing from './screens/Landing';
import CapturaNome from './screens/CapturaNome';
import Bloco1 from './screens/Bloco1';
import Bloco2 from './screens/Bloco2';
import Bloco3 from './screens/Bloco3';
import Bloco4 from './screens/Bloco4';
import Bloco5 from './screens/Bloco5';
import CapturaContato from './screens/CapturaContato';
import Loading from './screens/Loading';
import Resultado from './screens/Resultado';
import { AnimatePresence } from 'motion/react';

function AppContent() {
  const { telaAtual } = useDiagnostico();

  const renderTela = () => {
    switch (telaAtual) {
      case 'landing': return <Landing key="landing" />;
      case 'captura-nome': return <CapturaNome key="captura-nome" />;
      case 'bloco1': return <Bloco1 key="bloco1" />;
      case 'bloco2': return <Bloco2 key="bloco2" />;
      case 'bloco3': return <Bloco3 key="bloco3" />;
      case 'bloco4': return <Bloco4 key="bloco4" />;
      case 'bloco5': return <Bloco5 key="bloco5" />;
      case 'captura-contato': return <CapturaContato key="captura-contato" />;
      case 'loading': return <Loading key="loading" />;
      case 'resultado': return <Resultado key="resultado" />;
      default: return <Landing key="landing" />;
    }
  };

  return (
    <main className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-[#00C896] selection:text-black flex flex-col items-center">
      <div className="w-full max-w-[640px] px-5 py-8 min-h-screen flex flex-col">
        <AnimatePresence mode="wait">
          {renderTela()}
        </AnimatePresence>
      </div>
    </main>
  );
}

export default function App() {
  return (
    <DiagnosticoProvider>
      <AppContent />
    </DiagnosticoProvider>
  );
}
