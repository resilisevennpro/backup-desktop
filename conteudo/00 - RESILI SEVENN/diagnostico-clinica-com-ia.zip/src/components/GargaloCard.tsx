export default function GargaloCard() { return <div>GargaloCard</div>; }
