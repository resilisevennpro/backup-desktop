import { motion } from 'motion/react';
import { Check } from 'lucide-react';

interface OptionButtonProps {
  text: string;
  selected: boolean;
  onClick: () => void;
  index: number;
}

export default function OptionButton({ text, selected, onClick, index }: OptionButtonProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.08 }}
      onClick={onClick}
      className={`
        w-full text-left flex items-center justify-between rounded-xl px-5 py-4 transition-all duration-200
        ${selected 
          ? 'bg-[#0a1f18] border-2 border-[#00C896] shadow-[0_0_15px_rgba(0,200,150,0.15)]' 
          : 'bg-[#141414] border border-[#2a2a2a] hover:bg-[#0f1f1a] hover:border-[#00C896] hover:shadow-[0_0_10px_rgba(0,200,150,0.05)]'
        }
      `}
    >
      <span className="text-white text-sm md:text-base pr-4">{text}</span>
      {selected && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="flex-shrink-0"
        >
          <Check className="w-5 h-5 text-[#00C896]" />
        </motion.div>
      )}
    </motion.button>
  );
}
