import { motion } from 'motion/react';

interface ProgressBarProps {
  step: number;
  totalSteps: number;
  percentage: number;
}

export default function ProgressBar({ step, totalSteps, percentage }: ProgressBarProps) {
  return (
    <div className="w-full flex flex-col gap-2 mb-8">
      <div className="flex justify-between items-center text-sm font-semibold text-[#6B7280] uppercase tracking-wider">
        <span>Etapa {step} de {totalSteps}</span>
        <span>{percentage}%</span>
      </div>
      <div className="h-2 w-full bg-[#1a1a1a] rounded-full overflow-hidden">
        <motion.div 
          className="h-full bg-[#00C896] rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}
