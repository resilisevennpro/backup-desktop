import { ReactNode } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft } from 'lucide-react';

interface QuestionCardProps {
  title: string;
  subtitle: string;
  onBack: () => void;
  onNext: () => void;
  canGoNext: boolean;
  children: ReactNode;
}

export default function QuestionCard({ title, subtitle, onBack, onNext, canGoNext, children }: QuestionCardProps) {
  return (
    <div className="flex flex-col flex-1 w-full">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-2">{title}</h2>
        <p className="text-[#6B7280] text-sm md:text-base">{subtitle}</p>
      </div>

      <div className="flex-1 flex flex-col gap-8">
        {children}
      </div>

      <div className="flex items-center gap-4 mt-10 pt-6 border-t border-[#2a2a2a]">
        <button 
          onClick={onBack}
          className="flex items-center justify-center w-12 h-12 rounded-xl border border-[#2a2a2a] text-[#6B7280] hover:text-white hover:border-[#6B7280] transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        
        <button 
          onClick={onNext}
          disabled={!canGoNext}
          className="flex-1 bg-[#00C896] text-[#0a0a0a] font-bold rounded-[10px] py-4 hover:brightness-110 hover:scale-[1.02] transition-all duration-200 disabled:opacity-50 disabled:hover:scale-100 disabled:hover:brightness-100"
        >
          Próximo →
        </button>
      </div>
    </div>
  );
}
