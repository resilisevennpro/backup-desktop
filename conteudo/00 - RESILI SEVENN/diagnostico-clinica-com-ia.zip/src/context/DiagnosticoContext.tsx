import { createContext, useContext, useState, ReactNode } from 'react';

export type Tela = 'landing' | 'captura-nome' | 'bloco1' | 'bloco2' | 'bloco3' | 'bloco4' | 'bloco5' | 'captura-contato' | 'loading' | 'resultado';

interface Respostas {
  [key: string]: any;
}

interface DiagnosticoContextData {
  telaAtual: Tela;
  setTelaAtual: (tela: Tela) => void;
  nome: string;
  setNome: (nome: string) => void;
  whatsapp: string;
  setWhatsapp: (whatsapp: string) => void;
  instagram: string;
  setInstagram: (instagram: string) => void;
  respostas: Respostas;
  score: number;
  perfil: string;
  resultado: any;
  setResultado: (resultado: any) => void;
  adicionarResposta: (perguntaId: string, resposta: any, pontos: number) => void;
}

const DiagnosticoContext = createContext<DiagnosticoContextData>({} as DiagnosticoContextData);

export function DiagnosticoProvider({ children }: { children: ReactNode }) {
  const [telaAtual, setTelaAtual] = useState<Tela>('landing');
  const [nome, setNome] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [instagram, setInstagram] = useState('');
  const [respostas, setRespostas] = useState<Respostas>({});
  const [score, setScore] = useState(0);
  const [perfil, setPerfil] = useState('');
  const [resultado, setResultado] = useState<any>(null);

  const calcularPerfil = (novoScore: number) => {
    if (novoScore <= 30) return 'Clínica Invisível';
    if (novoScore <= 55) return 'Clínica com Potencial Represado';
    if (novoScore <= 75) return 'Clínica em Transição';
    return 'Clínica Pronta para Escalar';
  };

  const adicionarResposta = (perguntaId: string, resposta: any, pontos: number) => {
    setRespostas(prev => {
      const novasRespostas = { ...prev, [perguntaId]: { resposta, pontos } };
      
      // Recalcular score total
      let novoScore = 0;
      Object.values(novasRespostas).forEach((item: any) => {
        novoScore += item.pontos;
      });
      
      // Garantir que o score fique entre 0 e 100
      novoScore = Math.max(0, Math.min(100, novoScore));
      
      setScore(novoScore);
      setPerfil(calcularPerfil(novoScore));
      
      return novasRespostas;
    });
  };

  return (
    <DiagnosticoContext.Provider value={{
      telaAtual, setTelaAtual,
      nome, setNome,
      whatsapp, setWhatsapp,
      instagram, setInstagram,
      respostas,
      score,
      perfil,
      resultado, setResultado,
      adicionarResposta
    }}>
      {children}
    </DiagnosticoContext.Provider>
  );
}

export const useDiagnostico = () => useContext(DiagnosticoContext);
