import { useState } from 'react';
import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import ProgressBar from '../components/ProgressBar';
import QuestionCard from '../components/QuestionCard';
import OptionButton from '../components/OptionButton';

export default function Bloco1() {
  const { nome, setTelaAtual, adicionarResposta, respostas } = useDiagnostico();
  
  const [q1, setQ1] = useState<string | null>(respostas['q1']?.resposta || null);
  const [q2, setQ2] = useState<string | null>(respostas['q2']?.resposta || null);
  const [q3, setQ3] = useState<string | null>(respostas['q3']?.resposta || null);

  const optionsQ1 = [
    { text: 'Quase todos por indicação de amigos e família', points: 0 },
    { text: 'Me encontram na internet (Instagram e/ou Google Maps)', points: 6 },
    { text: 'Por Tráfego Pago (anúncios online)', points: 8 },
    { text: 'Todos os canais acima', points: 10 },
    { text: 'Não sei de onde, não tenho controle', points: -5 },
  ];

  const optionsQ2 = [
    { text: 'Agenda sempre cheia, estou até recusando pacientes', points: 10 },
    { text: 'Agenda razoável, mas poderia ser melhor', points: 5 },
    { text: 'Tenho muitos horários vagos toda semana', points: 0 },
    { text: 'A agenda está muito abaixo do que eu gostaria', points: -5 },
    { text: 'Não tenho controle de quantos horários vazios tenho', points: -5 },
  ];

  const optionsQ3 = [
    { text: 'Sim, invisto e tenho bons resultados', points: 10 },
    { text: 'Sim, mas já gastei dinheiro sem resultado', points: 4 },
    { text: 'Não invisto — dependo só de Instagram e Indicação', points: 2 },
    { text: 'Não sei / Nunca tentei', points: -5 },
  ];

  const handleNext = () => {
    if (q1 && q2 && q3) {
      adicionarResposta('q1', q1, optionsQ1.find(o => o.text === q1)?.points || 0);
      adicionarResposta('q2', q2, optionsQ2.find(o => o.text === q2)?.points || 0);
      adicionarResposta('q3', q3, optionsQ3.find(o => o.text === q3)?.points || 0);
      setTelaAtual('bloco2');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col flex-1 w-full"
    >
      <ProgressBar step={2} totalSteps={6} percentage={33} />
      
      <QuestionCard 
        title="Presença e Atração"
        subtitle={`${nome}, vamos entender como novos pacientes chegam até você hoje.`}
        onBack={() => setTelaAtual('captura-nome')}
        onNext={handleNext}
        canGoNext={!!(q1 && q2 && q3)}
      >
        <div className="flex flex-col gap-10">
          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">1. Como a maioria dos seus pacientes novos chega até a sua clínica?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ1.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q1 === opt.text} 
                  onClick={() => setQ1(opt.text)} 
                />
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">2. Como está a sua agenda atualmente?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ2.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q2 === opt.text} 
                  onClick={() => setQ2(opt.text)} 
                />
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">3. Hoje a clínica investe dinheiro em anúncios pagos (Instagram Ads, Google Ads)?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ3.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q3 === opt.text} 
                  onClick={() => setQ3(opt.text)} 
                />
              ))}
            </div>
          </div>
        </div>
      </QuestionCard>
    </motion.div>
  );
}
