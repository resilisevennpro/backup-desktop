import { useState } from 'react';
import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import ProgressBar from '../components/ProgressBar';
import QuestionCard from '../components/QuestionCard';
import OptionButton from '../components/OptionButton';

export default function Bloco2() {
  const { setTelaAtual, adicionarResposta, respostas } = useDiagnostico();
  
  const [q4, setQ4] = useState<string | null>(respostas['q4']?.resposta || null);
  const [q5, setQ5] = useState<string | null>(respostas['q5']?.resposta || null);
  const [q6, setQ6] = useState<string | null>(respostas['q6']?.resposta || null);

  const optionsQ4 = [
    { text: 'Menos de 5 minutos — respondemos na hora', points: 10 },
    { text: 'Entre 5 e 30 minutos', points: 6 },
    { text: 'Entre 30 minutos e 2 horas', points: 2 },
    { text: 'Mais de 2 horas ou só no dia seguinte', points: -5 },
    { text: 'Não sei quanto tempo leva', points: -5 },
  ];

  const optionsQ5 = [
    { text: 'Temos um processo de reativação entramos em contato por varias vezes', points: 10 },
    { text: 'Às vezes lembramos de dar um retorno', points: 4 },
    { text: 'Geralmente não temos tempo para retornar', points: 0 },
    { text: 'Não fazemos nada, esperamos o paciente voltar', points: -5 },
    { text: 'Não sei / Nunca pensamos nisso', points: -5 },
  ];

  const optionsQ6 = [
    { text: 'Tenho uma secretária ou equipe dedicada com script pronto', points: 10 },
    { text: 'A recepcionista/secretária responde mas sem script pronto', points: 4 },
    { text: 'Não há um responsável fixo — eu ou a secretária responde', points: 2 },
    { text: 'Eu mesmo respondo, não tenho secretária', points: -5 },
  ];

  const handleNext = () => {
    if (q4 && q5 && q6) {
      adicionarResposta('q4', q4, optionsQ4.find(o => o.text === q4)?.points || 0);
      adicionarResposta('q5', q5, optionsQ5.find(o => o.text === q5)?.points || 0);
      adicionarResposta('q6', q6, optionsQ6.find(o => o.text === q6)?.points || 0);
      setTelaAtual('bloco3');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col flex-1 w-full"
    >
      <ProgressBar step={3} totalSteps={6} percentage={50} />
      
      <QuestionCard 
        title="Atendimento e Conversão"
        subtitle="Aqui está o maior buraco de faturamento da maioria das clínicas."
        onBack={() => setTelaAtual('bloco1')}
        onNext={handleNext}
        canGoNext={!!(q4 && q5 && q6)}
      >
        <div className="flex flex-col gap-10">
          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">4. Quando alguém manda mensagem perguntando sobre um procedimento, quanto tempo leva para receber uma resposta?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ4.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q4 === opt.text} 
                  onClick={() => setQ4(opt.text)} 
                />
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">5. Quando um paciente pede informações mas não agenda na hora ou para de responder — o que acontece depois?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ5.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q5 === opt.text} 
                  onClick={() => setQ5(opt.text)} 
                />
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">6. Quem responde os pacientes no WhatsApp hoje?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ6.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q6 === opt.text} 
                  onClick={() => setQ6(opt.text)} 
                />
              ))}
            </div>
          </div>
        </div>
      </QuestionCard>
    </motion.div>
  );
}
