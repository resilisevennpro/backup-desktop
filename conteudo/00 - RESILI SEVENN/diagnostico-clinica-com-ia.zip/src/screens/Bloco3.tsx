import { useState } from 'react';
import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import ProgressBar from '../components/ProgressBar';
import QuestionCard from '../components/QuestionCard';
import OptionButton from '../components/OptionButton';

export default function Bloco3() {
  const { nome, setTelaAtual, adicionarResposta, respostas } = useDiagnostico();
  
  const [q7, setQ7] = useState<string | null>(respostas['q7']?.resposta || null);
  const [q8, setQ8] = useState<string | null>(respostas['q8']?.resposta || null);

  const optionsQ7 = [
    { text: '7 ou mais — a maioria agenda', points: 10 },
    { text: 'Entre 4 e 6 — metade converte', points: 6 },
    { text: 'Menos de 3 — a maioria some', points: 2 },
    { text: 'Não faço essa conta / Não sei', points: -5 },
  ];

  const optionsQ8 = [
    { text: 'Sim, sei exatamente qual é e foco nele', points: 10 },
    { text: 'Tenho uma ideia, mas não tenho certeza', points: 5 },
    { text: 'Não sei / Nunca parei para ver isso', points: -5 },
  ];

  const handleNext = () => {
    if (q7 && q8) {
      adicionarResposta('q7', q7, optionsQ7.find(o => o.text === q7)?.points || 0);
      adicionarResposta('q8', q8, optionsQ8.find(o => o.text === q8)?.points || 0);
      setTelaAtual('bloco4');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col flex-1 w-full"
    >
      <ProgressBar step={4} totalSteps={6} percentage={66} />
      
      <QuestionCard 
        title="Controle e Números"
        subtitle={`${nome}, aquilo que não é medido/controlado, não é possível de gerenciar. Vamos ver onde a sua operação está.`}
        onBack={() => setTelaAtual('bloco2')}
        onNext={handleNext}
        canGoNext={!!(q7 && q8)}
      >
        <div className="flex flex-col gap-10">
          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">7. De cada 10 pessoas que entram em contato perguntando sobre um procedimento, quantas viram pacientes de fato?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ7.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q7 === opt.text} 
                  onClick={() => setQ7(opt.text)} 
                />
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">8. Você sabe qual procedimento traz mais faturamento para a sua clínica hoje?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ8.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q8 === opt.text} 
                  onClick={() => setQ8(opt.text)} 
                />
              ))}
            </div>
          </div>
        </div>
      </QuestionCard>
    </motion.div>
  );
}
