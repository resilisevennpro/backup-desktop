import { useState } from 'react';
import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import ProgressBar from '../components/ProgressBar';
import QuestionCard from '../components/QuestionCard';
import OptionButton from '../components/OptionButton';

export default function Bloco4() {
  const { setTelaAtual, adicionarResposta, respostas } = useDiagnostico();
  
  const [q9, setQ9] = useState<string | null>(respostas['q9']?.resposta || null);
  const [q10, setQ10] = useState<string | null>(respostas['q10']?.resposta || null);

  const optionsQ9 = [
    { text: 'Sim — temos um protocolo de pós-atendimento e reativação', points: 10 },
    { text: 'Às vezes mandamos uma mensagem em datas comemorativas', points: 4 },
    { text: 'Não — esperamos que o paciente volte por conta própria', points: 0 },
    { text: 'Nunca pensei nisso / Não temos processo', points: -5 },
  ];

  const optionsQ10 = [
    { text: 'Sim, tenho esse número exato ou aproximado', points: 10 },
    { text: 'Tenho uma ideia mas não é preciso', points: 5 },
    { text: 'Não sei / Não tenho como ver isso agora', points: -5 },
  ];

  const handleNext = () => {
    if (q9 && q10) {
      adicionarResposta('q9', q9, optionsQ9.find(o => o.text === q9)?.points || 0);
      adicionarResposta('q10', q10, optionsQ10.find(o => o.text === q10)?.points || 0);
      setTelaAtual('bloco5');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col flex-1 w-full"
    >
      <ProgressBar step={5} totalSteps={6} percentage={83} />
      
      <QuestionCard 
        title="Retenção e Recorrência"
        subtitle={`Paciente que volta vale mais do que paciente novo. Veja como está a sua clínica.`}
        onBack={() => setTelaAtual('bloco3')}
        onNext={handleNext}
        canGoNext={!!(q9 && q10)}
      >
        <div className="flex flex-col gap-10">
          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">9. Depois que um paciente faz um procedimento, a clínica mantém contato com ele?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ9.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q9 === opt.text} 
                  onClick={() => setQ9(opt.text)} 
                />
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">10. Você sabe quantos pacientes a clínica atendeu em média nos últimos 3 meses?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ10.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q10 === opt.text} 
                  onClick={() => setQ10(opt.text)} 
                />
              ))}
            </div>
          </div>
        </div>
      </QuestionCard>
    </motion.div>
  );
}
