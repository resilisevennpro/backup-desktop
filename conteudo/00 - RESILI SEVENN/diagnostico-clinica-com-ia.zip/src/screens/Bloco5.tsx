import { useState } from 'react';
import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import ProgressBar from '../components/ProgressBar';
import QuestionCard from '../components/QuestionCard';
import OptionButton from '../components/OptionButton';

export default function Bloco5() {
  const { setTelaAtual, adicionarResposta, respostas } = useDiagnostico();
  
  const [q11, setQ11] = useState<string | null>(respostas['q11']?.resposta || null);
  const [q12, setQ12] = useState<string>(respostas['q12']?.resposta || '');

  const optionsQ11 = [
    { text: 'Menos de R$ 20.000', points: 0 },
    { text: 'Entre R$ 20.000 e R$ 40.000', points: 0 },
    { text: 'Entre R$ 40.000 e R$ 80.000', points: 0 },
    { text: 'Acima de R$ 80.000', points: 0 },
    { text: 'Prefiro não informar', points: 0 },
  ];

  const handleNext = () => {
    if (q11 && q12.trim()) {
      adicionarResposta('q11', q11, 0);
      adicionarResposta('q12', q12, 0);
      setTelaAtual('captura-contato');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col flex-1 w-full"
    >
      <ProgressBar step={6} totalSteps={6} percentage={100} />
      
      <QuestionCard 
        title="Momento da Clínica e Dor"
        subtitle="Últimas perguntas. Essas respostas definem o seu plano de crescimento."
        onBack={() => setTelaAtual('bloco4')}
        onNext={handleNext}
        canGoNext={!!(q11 && q12.trim())}
      >
        <div className="flex flex-col gap-10">
          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">11. Quanto a clínica fatura por mês hoje, em média?</h3>
            <div className="flex flex-col gap-3">
              {optionsQ11.map((opt, i) => (
                <OptionButton 
                  key={i} 
                  index={i} 
                  text={opt.text} 
                  selected={q11 === opt.text} 
                  onClick={() => setQ11(opt.text)} 
                />
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <h3 className="text-lg font-semibold text-white">12. O que mais te preocupa na clínica hoje?</h3>
            <textarea
              value={q12}
              onChange={(e) => setQ12(e.target.value)}
              placeholder="Ex: Dificuldade em captar mais pacientes, dificuldade em fechar orçamentos..."
              className="bg-[#141414] border border-[#2a2a2a] text-white rounded-xl px-4 py-4 min-h-[120px] focus:outline-none focus:border-[#00C896] focus:shadow-[0_0_15px_rgba(0,200,150,0.15)] transition-all resize-none"
            />
          </div>
        </div>
      </QuestionCard>
    </motion.div>
  );
}
