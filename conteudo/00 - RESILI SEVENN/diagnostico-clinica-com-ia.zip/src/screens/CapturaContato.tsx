import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import ProgressBar from '../components/ProgressBar';
import { Bot, Lock } from 'lucide-react';

export default function CapturaContato() {
  const { whatsapp, setWhatsapp, instagram, setInstagram, setTelaAtual } = useDiagnostico();

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (whatsapp.trim()) {
      setTelaAtual('loading');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col flex-1 w-full"
    >
      <ProgressBar step={6} totalSteps={6} percentage={100} />

      <div className="flex-1 flex flex-col justify-center mt-4">
        <div className="inline-flex items-center gap-2 bg-[#111111] border border-[#2a2a2a] rounded-full px-4 py-2 mb-6 self-start">
          <Bot className="w-4 h-4 text-[#00C896]" />
          <span className="text-sm font-semibold text-white uppercase tracking-wider">Análise pronta!</span>
        </div>

        <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">
          O seu diagnóstico está pronto.
        </h2>
        <p className="text-[#6B7280] mb-8">
          Informe seus dados para ver o resultado na próxima tela.
        </p>

        <form onSubmit={handleNext} className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <label htmlFor="whatsapp" className="text-sm font-semibold text-[#6B7280] uppercase tracking-wider">
              Seu WhatsApp com DDD
            </label>
            <input
              id="whatsapp"
              type="tel"
              required
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              placeholder="Ex: (11) 99999-9999"
              className="bg-[#141414] border border-[#2a2a2a] text-white rounded-xl px-4 py-4 focus:outline-none focus:border-[#00C896] focus:shadow-[0_0_15px_rgba(0,200,150,0.15)] transition-all"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label htmlFor="instagram" className="text-sm font-semibold text-[#6B7280] uppercase tracking-wider">
              Instagram da clínica <span className="text-xs text-[#4B5563]">(opcional)</span>
            </label>
            <input
              id="instagram"
              type="text"
              value={instagram}
              onChange={(e) => setInstagram(e.target.value)}
              placeholder="Ex: @suaclinica"
              className="bg-[#141414] border border-[#2a2a2a] text-white rounded-xl px-4 py-4 focus:outline-none focus:border-[#00C896] focus:shadow-[0_0_15px_rgba(0,200,150,0.15)] transition-all"
            />
          </div>

          <button 
            type="submit"
            disabled={!whatsapp.trim()}
            className="mt-4 w-full bg-[#00C896] text-[#0a0a0a] font-bold rounded-[10px] px-8 py-4 hover:brightness-110 hover:scale-[1.02] transition-all duration-200 disabled:opacity-50 disabled:hover:scale-100 disabled:hover:brightness-100"
          >
            Ver meu diagnóstico →
          </button>
        </form>

        <div className="flex items-center justify-center gap-2 mt-8 text-[#6B7280] text-xs">
          <Lock className="w-3 h-3" />
          <span>Seus dados são confidenciais e não serão compartilhados</span>
        </div>
      </div>
    </motion.div>
  );
}
