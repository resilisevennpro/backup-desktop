import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import ProgressBar from '../components/ProgressBar';

export default function CapturaNome() {
  const { nome, setNome, setTelaAtual } = useDiagnostico();

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (nome.trim()) {
      setTelaAtual('bloco1');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col flex-1 w-full"
    >
      <ProgressBar step={1} totalSteps={6} percentage={16} />

      <div className="flex-1 flex flex-col justify-center mt-8">
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-8">
          Como a IA deve te chamar?
        </h2>

        <form onSubmit={handleNext} className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <label htmlFor="nome" className="text-sm font-semibold text-[#6B7280] uppercase tracking-wider">
              Seu nome e sobrenome
            </label>
            <input
              id="nome"
              type="text"
              required
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Ex: Dra. Amanda Nunes"
              className="bg-[#141414] border border-[#2a2a2a] text-white rounded-xl px-4 py-4 focus:outline-none focus:border-[#00C896] focus:shadow-[0_0_15px_rgba(0,200,150,0.15)] transition-all"
            />
          </div>

          <button 
            type="submit"
            disabled={!nome.trim()}
            className="mt-4 w-full bg-[#00C896] text-[#0a0a0a] font-bold rounded-[10px] px-8 py-4 hover:brightness-110 hover:scale-[1.02] transition-all duration-200 disabled:opacity-50 disabled:hover:scale-100 disabled:hover:brightness-100"
          >
            Iniciar meu diagnóstico →
          </button>
        </form>
      </div>
    </motion.div>
  );
}
