import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import { Activity, Clock, Bot } from 'lucide-react';

export default function Landing() {
  const { setTelaAtual } = useDiagnostico();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex flex-col items-center justify-center flex-1 w-full"
    >
      <div className="inline-flex items-center gap-2 bg-[#111111] border border-[#2a2a2a] rounded-full px-4 py-2 mb-8">
        <Bot className="w-4 h-4 text-[#00C896]" />
        <span className="text-sm font-semibold text-white uppercase tracking-wider">Diagnóstico com IA</span>
      </div>

      <h1 className="text-3xl md:text-4xl font-bold text-white mb-6 text-center leading-tight">
        Descubra quanto você está deixando de <span className="text-[#00C896]">faturar</span> no seu consultório.
      </h1>
      
      <p className="text-[#6B7280] text-center text-lg mb-10">
        Nossa IA analisa a operação comercial e de marketing da sua clínica e revela os buracos que impedem você de dobrar o faturamento.
      </p>

      <div className="flex flex-col sm:flex-row gap-6 mb-12 w-full justify-center">
        <div className="flex items-center gap-3 text-[#6B7280]">
          <Clock className="w-5 h-5 text-[#00C896]" />
          <span className="text-sm">Menos de 2 minutos</span>
        </div>
        <div className="flex items-center gap-3 text-[#6B7280]">
          <Activity className="w-5 h-5 text-[#00C896]" />
          <span className="text-sm">Baseado na sua realidade</span>
        </div>
      </div>

      <button 
        onClick={() => setTelaAtual('captura-nome')}
        className="w-full sm:w-auto bg-[#00C896] text-[#0a0a0a] font-bold rounded-[10px] px-8 py-4 hover:brightness-110 hover:scale-[1.02] transition-all duration-200 shadow-[0_0_30px_rgba(0,200,150,0.2)] hover:shadow-[0_0_30px_rgba(0,200,150,0.4)]"
      >
        Quero descobrir meu diagnóstico gratuito →
      </button>

      <p className="mt-8 text-xs text-[#6B7280] text-center">
        Mais de 500 clínicas já descobriram seu potencial oculto
      </p>
    </motion.div>
  );
}
