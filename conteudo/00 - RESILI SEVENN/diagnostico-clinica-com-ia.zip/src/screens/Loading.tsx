import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import { Bot } from 'lucide-react';
import { gerarDiagnostico, enviarParaSheets } from '../services/api';

const steps = [
  "Verificando volume de atração de pacientes...",
  "Calculando perdas no processo de atendimento...",
  "Mapeando gargalos de conversão...",
  "Estimando faturamento não capturado...",
  "Gerando seu diagnóstico personalizado..."
];

export default function Loading() {
  const { setTelaAtual, setResultado, ...dados } = useDiagnostico();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Animação da barra de progresso (0 a 100 em 4s)
    const duration = 4000;
    const interval = 50;
    const totalSteps = duration / interval;
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep++;
      setProgress(Math.min(100, (currentStep / totalSteps) * 100));
      if (currentStep >= totalSteps) {
        clearInterval(timer);
      }
    }, interval);

    // Chamada da API em background
    const processData = async () => {
      try {
        // Gerar diagnóstico com IA primeiro para ter os dados
        const resultadoIA = await gerarDiagnostico({
          nome: dados.nome,
          score: dados.score,
          perfil: dados.perfil,
          respostas: dados.respostas
        });
        
        setResultado(resultadoIA);

        // Enviar para Sheets com o novo payload
        const payloadSheets = {
          data_hora: new Date().toISOString(),
          nome: dados.nome,
          whatsapp: dados.whatsapp,
          instagram: dados.instagram,
          
          score: dados.score,
          perfil: dados.perfil,
          
          q1_origem_pacientes: dados.respostas['q1']?.resposta || '',
          q2_situacao_agenda: dados.respostas['q2']?.resposta || '',
          q3_investe_anuncios: dados.respostas['q3']?.resposta || '',
          
          q4_tempo_resposta: dados.respostas['q4']?.resposta || '',
          q5_followup: dados.respostas['q5']?.resposta || '',
          q6_quem_responde: dados.respostas['q6']?.resposta || '',
          
          q7_conversao_contatos: dados.respostas['q7']?.resposta || '',
          q8_procedimento_top: dados.respostas['q8']?.resposta || '',
          
          q9_retencao: dados.respostas['q9']?.resposta || '',
          q10_controle_pacientes: dados.respostas['q10']?.resposta || '',
          
          q11_faturamento: dados.respostas['q11']?.resposta || '',
          q12_maior_dor: dados.respostas['q12']?.resposta || '',
          
          valor_perdido_mes: resultadoIA.valor_perdido_mes || 0,
          gargalo_1_titulo: resultadoIA.gargalo_1?.titulo || '',
          gargalo_1_descricao: resultadoIA.gargalo_1?.descricao || '',
          gargalo_2_titulo: resultadoIA.gargalo_2?.titulo || '',
          gargalo_2_descricao: resultadoIA.gargalo_2?.descricao || '',
          gargalo_3_titulo: resultadoIA.gargalo_3?.titulo || '',
          gargalo_3_descricao: resultadoIA.gargalo_3?.descricao || ''
        };
        
        // Não aguardamos o envio para o Sheets para não bloquear a UI
        enviarParaSheets(payloadSheets);
        
        // Aguarda pelo menos 4 segundos (animação) antes de mudar de tela
        setTimeout(() => {
          setTelaAtual('resultado');
        }, Math.max(0, 4000 - currentStep * interval));
        
      } catch (error) {
        console.error("Erro no processamento:", error);
        // Em caso de erro, ainda vamos para a tela de resultado (o fallback da API vai garantir um resultado)
        setTimeout(() => {
          setTelaAtual('resultado');
        }, 1000);
      }
    };

    processData();

    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center flex-1 w-full"
    >
      <motion.div 
        animate={{ rotate: 360 }}
        transition={{ duration: 4, ease: "linear", repeat: Infinity }}
        className="mb-8"
      >
        <Bot className="w-16 h-16 text-[#00C896]" />
      </motion.div>

      <h2 className="text-2xl font-bold text-white mb-10 text-center">
        Analisando seus dados...
      </h2>

      <div className="w-full flex flex-col gap-4 mb-12">
        {steps.map((step, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.8, duration: 0.5 }}
            className="flex items-center gap-3 text-[#6B7280]"
          >
            <span className="text-[#00C896]">✦</span>
            <span className="text-sm md:text-base">{step}</span>
          </motion.div>
        ))}
      </div>

      <div className="w-full h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
        <div 
          className="h-full bg-[#00C896] rounded-full transition-all duration-100 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>
    </motion.div>
  );
}
