import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { useDiagnostico } from '../context/DiagnosticoContext';
import { Bot, AlertTriangle, Target, Clock, Heart, TrendingUp, Users, Zap } from 'lucide-react';

export default function Resultado() {
  const { nome, score, perfil, resultado } = useDiagnostico();
  const [displayScore, setDisplayScore] = useState(0);
  const [displayValor, setDisplayValor] = useState(0);

  useEffect(() => {
    if (!resultado) return;

    // Animação do score
    const scoreDuration = 1500;
    const scoreSteps = 30;
    const scoreInterval = scoreDuration / scoreSteps;
    let currentScoreStep = 0;

    const scoreTimer = setInterval(() => {
      currentScoreStep++;
      setDisplayScore(Math.floor((currentScoreStep / scoreSteps) * score));
      if (currentScoreStep >= scoreSteps) {
        setDisplayScore(score);
        clearInterval(scoreTimer);
      }
    }, scoreInterval);

    // Animação do valor perdido
    const valor = resultado.valor_perdido_mes || 0;
    let currentValorStep = 0;
    
    const valorTimer = setInterval(() => {
      currentValorStep++;
      setDisplayValor(Math.floor((currentValorStep / scoreSteps) * valor));
      if (currentValorStep >= scoreSteps) {
        setDisplayValor(valor);
        clearInterval(valorTimer);
      }
    }, scoreInterval);

    return () => {
      clearInterval(scoreTimer);
      clearInterval(valorTimer);
    };
  }, [score, resultado]);

  if (!resultado) return null;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col flex-1 w-full pb-12"
    >
      {/* Seção 1 — Índice */}
      <div className="flex flex-col items-center text-center mb-12">
        <div className="inline-flex items-center gap-2 bg-[#111111] border border-[#2a2a2a] rounded-full px-4 py-2 mb-6">
          <Bot className="w-4 h-4 text-[#00C896]" />
          <span className="text-sm font-semibold text-white uppercase tracking-wider">Análise completa por IA</span>
        </div>
        
        <h1 className="text-3xl font-bold text-white mb-6">Diagnóstico {nome}</h1>
        
        <div className="flex flex-col items-center justify-center w-40 h-40 rounded-full border-4 border-[#00C896] shadow-[0_0_30px_rgba(0,200,150,0.2)] mb-4">
          <span className="text-5xl font-bold text-[#00C896]">{displayScore}</span>
          <span className="text-[#6B7280] text-sm uppercase tracking-wider mt-1">Score</span>
        </div>
        
        <p className="text-xl font-semibold text-[#6B7280]">{perfil}</p>
      </div>

      {/* Seção 2 — Sangramento */}
      <div className="bg-[#1a0a0a] border-l-4 border-[#C8102E] rounded-r-xl p-6 mb-12">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className="w-5 h-5 text-[#C8102E]" />
          <span className="text-sm font-bold text-[#C8102E] uppercase tracking-wider">O Sangramento Financeiro — {nome}</span>
        </div>
        <p className="text-[#6B7280] mb-4">Baseado nas suas respostas, você está deixando de faturar em média:</p>
        <div className="text-4xl md:text-5xl font-bold text-[#C8102E] mb-2">
          {formatCurrency(displayValor)} <span className="text-xl text-[#6B7280] font-normal">/mês</span>
        </div>
        <p className="text-sm text-[#6B7280]">
          Isso pode representar quase <strong className="text-white">{formatCurrency(displayValor * 12)}</strong> perdidos nos próximos 12 meses caso continue com os mesmos processos e estratégias atuais.
        </p>
      </div>

      {/* Seção 3 — Gargalos */}
      <div className="mb-12">
        <h2 className="text-xl font-bold text-white mb-6">{nome}, os 3 maiores gargalos hoje são:</h2>
        <div className="flex flex-col gap-4">
          {[
            { id: 'gargalo_1', color: '#C8102E', icon: AlertTriangle },
            { id: 'gargalo_2', color: '#D97706', icon: Target },
            { id: 'gargalo_3', color: '#EAB308', icon: Zap }
          ].map((item, index) => {
            const gargalo = resultado[item.id];
            if (!gargalo) return null;
            const Icon = item.icon;
            
            return (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                className="bg-[#111111] border-l-4 rounded-r-xl p-5"
                style={{ borderLeftColor: item.color }}
              >
                <div className="flex items-start gap-3">
                  <Icon className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: item.color }} />
                  <div>
                    <h3 className="font-bold text-white mb-1">{gargalo.titulo}</h3>
                    <p className="text-[#6B7280] text-sm leading-relaxed">{gargalo.descricao}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Seção 4 — Mensagem de perfil */}
      <div className="bg-[rgba(255,255,255,0.03)] backdrop-blur-[10px] border border-[#2a2a2a] rounded-xl p-6 mb-12 text-center">
        <p className="text-lg text-white italic leading-relaxed">
          "{resultado.mensagem_perfil}"
        </p>
      </div>

      {/* Seção 5 — O que isso significa */}
      <div className="mb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <div className="bg-[#111111] rounded-xl p-5 border border-[#2a2a2a]">
            <Clock className="w-6 h-6 text-[#00C896] mb-3" />
            <h4 className="font-bold text-white mb-1">Mais tempo livre</h4>
            <p className="text-xs text-[#6B7280]">Menos horas apagando incêndio, mais momentos que importam.</p>
          </div>
          <div className="bg-[#111111] rounded-xl p-5 border border-[#2a2a2a]">
            <Heart className="w-6 h-6 text-[#00C896] mb-3" />
            <h4 className="font-bold text-white mb-1">Menos estresse</h4>
            <p className="text-xs text-[#6B7280]">Mais tranquilidade, sem preocupações com agenda vazia.</p>
          </div>
          <div className="bg-[#111111] rounded-xl p-5 border border-[#2a2a2a]">
            <Users className="w-6 h-6 text-[#00C896] mb-3" />
            <h4 className="font-bold text-white mb-1">Pacientes qualificados</h4>
            <p className="text-xs text-[#6B7280]">Novos pacientes toda semana, sem depender de indicações.</p>
          </div>
          <div className="bg-[#111111] rounded-xl p-5 border border-[#2a2a2a]">
            <TrendingUp className="w-6 h-6 text-[#00C896] mb-3" />
            <h4 className="font-bold text-white mb-1">Crescimento constante</h4>
            <p className="text-xs text-[#6B7280]">Faturamento previsível e operação escalável.</p>
          </div>
        </div>

        <div className="w-full h-px bg-gradient-to-r from-transparent via-[#00C896] to-transparent opacity-30 mb-8"></div>

        <div className="text-center mb-10">
          <p className="text-[#6B7280] mb-4">Esse não é só um número. É a diferença entre uma clínica que sobrevive e uma que escala.</p>
          <p className="text-xl font-bold text-[#00C896] mb-4">A Resili Sevenn resolve esses gargalos.</p>
          <p className="text-sm text-[#6B7280]">
            Temos uma vaga disponível para sessão estratégica de 30 minutos 100% gratuita para falarmos mais sobre os gargalos da sua operação e desenvolvermos um plano de crescimento!
          </p>
        </div>

        <div className="flex flex-col gap-4">
          <button className="w-full bg-[#00C896] text-[#0a0a0a] font-bold rounded-[10px] px-8 py-4 hover:brightness-110 hover:scale-[1.02] transition-all duration-200 shadow-[0_0_30px_rgba(0,200,150,0.2)] hover:shadow-[0_0_30px_rgba(0,200,150,0.4)]">
            Quero minha sessão estratégica gratuita →
          </button>
          <button className="w-full bg-transparent border border-[rgba(0,200,150,0.4)] text-[#00C896] font-bold rounded-[10px] px-8 py-4 hover:bg-[rgba(0,200,150,0.08)] hover:border-[#00C896] transition-all duration-200">
            Falar com um especialista via WhatsApp
          </button>
        </div>
      </div>
    </motion.div>
  );
}
