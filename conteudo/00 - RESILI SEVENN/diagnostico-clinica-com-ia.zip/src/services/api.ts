import axios from 'axios';
import { GoogleGenAI, Type } from '@google/genai';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '',
  headers: {
    'Content-Type': 'application/json',
  },
});

export async function gerarDiagnostico(dados: any) {
  // We use Gemini API as per the environment constraints, adapting the prompt
  const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '' });

  const prompt = `
Você é um especialista em marketing e vendas para clínicas de estética facial e odontologia estética.

Responsável: ${dados.nome}
Score: ${dados.score}/100
Perfil: ${dados.perfil}
Respostas: ${JSON.stringify(dados.respostas, null, 2)}

Retorne APENAS um JSON válido, sem markdown, sem explicações, com esta estrutura exata:
{
  "gargalo_1": { "titulo": "", "descricao": "" },
  "gargalo_2": { "titulo": "", "descricao": "" },
  "gargalo_3": { "titulo": "", "descricao": "" },
  "mensagem_perfil": "",
  "valor_perdido_mes": 0,
  "proximo_passo": ""
}

Regras:
- Use linguagem simples, direta, sem jargão técnico
- Fale com o doutor, não com o marqueteiro
- Se a agenda estiver vazia ou depender de indicações, o gargalo de geração de demanda DEVE aparecer como gargalo_1
- Valor perdido deve ser estimado com base no faturamento informado e no score (quanto menor o score, maior a perda estimada)
- Descrições de no máximo 2 linhas cada
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            gargalo_1: {
              type: Type.OBJECT,
              properties: {
                titulo: { type: Type.STRING },
                descricao: { type: Type.STRING }
              }
            },
            gargalo_2: {
              type: Type.OBJECT,
              properties: {
                titulo: { type: Type.STRING },
                descricao: { type: Type.STRING }
              }
            },
            gargalo_3: {
              type: Type.OBJECT,
              properties: {
                titulo: { type: Type.STRING },
                descricao: { type: Type.STRING }
              }
            },
            mensagem_perfil: { type: Type.STRING },
            valor_perdido_mes: { type: Type.NUMBER },
            proximo_passo: { type: Type.STRING }
          },
          required: ["gargalo_1", "gargalo_2", "gargalo_3", "mensagem_perfil", "valor_perdido_mes", "proximo_passo"]
        }
      }
    });

    const text = response.text;
    if (text) {
      return JSON.parse(text);
    }
    throw new Error("Resposta vazia da IA");
  } catch (error) {
    console.error("Erro ao gerar diagnóstico:", error);
    // Fallback in case of error
    return {
      gargalo_1: { titulo: "Atração de Pacientes", descricao: "Dependência de indicações limita seu crescimento e previsibilidade." },
      gargalo_2: { titulo: "Tempo de Resposta", descricao: "Demora no atendimento faz você perder pacientes para a concorrência." },
      gargalo_3: { titulo: "Falta de Retenção", descricao: "Pacientes antigos não estão retornando por falta de processos de reativação." },
      mensagem_perfil: "Sua clínica tem potencial, mas precisa de processos comerciais estruturados para parar de perder dinheiro.",
      valor_perdido_mes: 15000,
      proximo_passo: "Implementar um CRM e treinar a equipe de atendimento."
    };
  }
}

export async function enviarParaSheets(dados: any) {
  const webhookUrl = import.meta.env.VITE_SHEETS_WEBHOOK_URL;
  if (!webhookUrl) {
    console.warn("VITE_SHEETS_WEBHOOK_URL não configurada. Pulando envio para o Sheets.");
    return;
  }

  try {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(dados),
      mode: 'no-cors' // Often needed for Google Apps Script webhooks from browser
    });
  } catch (error) {
    console.error("Erro ao enviar para o Sheets:", error);
  }
}
